# Simple Browser

Navegador Android nativo baseado em WebView.

## Versão

0.1.0

## Recursos atuais

- WebView real para abrir sites da internet dentro do aplicativo.
- Barra de endereço.
- Pesquisa no Google quando o texto digitado não parece ser um endereço.
- Voltar.
- Avançar.
- Recarregar.
- Botão Ir.
- JavaScript habilitado para sites modernos.
- DOM Storage habilitado.
- Downloads encaminhados para um aplicativo compatível do Android.
- Links HTTP/HTTPS permanecem dentro do navegador.
- Links especiais, como `mailto:` e `tel:`, são enviados ao aplicativo Android correspondente.
- Histórico básico da WebView.
- Estado da página restaurado após recriação da Activity.

## Build pelo GitHub Actions

1. Crie um repositório no GitHub.
2. Envie todo o conteúdo desta pasta para o repositório.
3. Use a branch `main`.
4. Abra a aba **Actions**.
5. Execute **Build Simple Browser APK**.
6. Quando terminar, abra o artefato `Simple-Browser-debug` e baixe o APK.

O workflow configura Java 17, Android SDK e Gradle 9.6 automaticamente no runner.

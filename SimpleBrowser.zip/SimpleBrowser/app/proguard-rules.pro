# Simple Browser: no custom ProGuard/R8 rules needed for v0.1.0.

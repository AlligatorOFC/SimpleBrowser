package com.alligatorofc.simplebrowser;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.text.TextUtils;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://www.google.com/";

    private WebView webView;
    private EditText addressBar;
    private Button backButton;
    private Button forwardButton;
    private Button reloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        buildInterface();
        configureWebView();

        if (savedInstanceState == null) {
            webView.loadUrl(HOME_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(16, 17, 20));

        LinearLayout addressRow = new LinearLayout(this);
        addressRow.setOrientation(LinearLayout.HORIZONTAL);
        addressRow.setGravity(Gravity.CENTER_VERTICAL);
        addressRow.setPadding(dp(8), dp(8), dp(8), dp(4));
        addressRow.setBackgroundColor(Color.rgb(24, 26, 31));

        addressBar = new EditText(this);
        addressBar.setSingleLine(true);
        addressBar.setHint("Pesquisar ou digitar endereço");
        addressBar.setTextColor(Color.WHITE);
        addressBar.setHintTextColor(Color.rgb(170, 173, 180));
        addressBar.setTextSize(15);
        addressBar.setPadding(dp(12), 0, dp(12), 0);
        addressBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        addressBar.setBackground(makeRoundedBackground(Color.rgb(39, 42, 49), 14));

        addressRow.addView(addressBar, new LinearLayout.LayoutParams(0, dp(48), 1f));

        Button goButton = makeButton("Ir");
        LinearLayout.LayoutParams goParams = new LinearLayout.LayoutParams(dp(58), dp(48));
        goParams.setMargins(dp(6), 0, 0, 0);
        addressRow.addView(goButton, goParams);

        LinearLayout controlsRow = new LinearLayout(this);
        controlsRow.setOrientation(LinearLayout.HORIZONTAL);
        controlsRow.setGravity(Gravity.CENTER_VERTICAL);
        controlsRow.setPadding(dp(8), dp(4), dp(8), dp(8));
        controlsRow.setBackgroundColor(Color.rgb(24, 26, 31));

        backButton = makeButton("Voltar");
        forwardButton = makeButton("Avançar");
        reloadButton = makeButton("Recarregar");

        controlsRow.addView(backButton, weightParams());
        controlsRow.addView(forwardButton, weightParams());
        controlsRow.addView(reloadButton, weightParams());

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);

        root.addView(addressRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(controlsRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        goButton.setOnClickListener(v -> navigateFromAddressBar());
        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            navigateFromAddressBar();
            return true;
        });
        backButton.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
        });
        forwardButton.setOnClickListener(v -> {
            if (webView.canGoForward()) webView.goForward();
        });
        reloadButton.setOnClickListener(v -> webView.reload());
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    return false;
                }
                return openExternalUri(uri);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    return false;
                }
                return openExternalUri(uri);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                addressBar.setText(url);
                addressBar.setSelection(addressBar.length());
                updateNavigationButtons();
            }
        });

        webView.setWebChromeClient(new WebChromeClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException ignored) {
                Toast.makeText(this, "Não foi possível abrir o download.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void navigateFromAddressBar() {
        String input = addressBar.getText().toString().trim();
        if (TextUtils.isEmpty(input)) return;

        String url;
        if (input.contains(" ")) {
            url = "https://www.google.com/search?q=" + Uri.encode(input);
        } else if (input.startsWith("http://") || input.startsWith("https://")) {
            url = input;
        } else if (input.startsWith("www.")) {
            url = "https://" + input;
        } else if (input.contains(".") && !input.contains("/")) {
            url = "https://" + input;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(input);
        }

        webView.loadUrl(url);
    }

    private boolean openExternalUri(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            return true;
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Nenhum aplicativo pode abrir este endereço.", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    private void updateNavigationButtons() {
        backButton.setEnabled(webView.canGoBack());
        forwardButton.setEnabled(webView.canGoForward());
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(13);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setPadding(dp(4), 0, dp(4), 0);
        button.setBackground(makeRoundedBackground(Color.rgb(39, 42, 49), 12));
        return button;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(44), 1f);
        params.setMargins(dp(2), 0, dp(2), 0);
        return params;
    }

    private GradientDrawable makeRoundedBackground(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
